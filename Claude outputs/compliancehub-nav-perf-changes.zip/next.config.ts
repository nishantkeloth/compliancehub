import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  experimental: {
    // Lets the client-side router cache reuse a shared layout (e.g. the
    // Crew Matrix / Team sidebars) across navigations for this many
    // seconds instead of re-rendering it from the server on every click.
    // Only matters once a route actually has a persistent layout segment
    // to reuse — see app/crew/layout.tsx and app/team/layout.tsx.
    staleTimes: {
      dynamic: 30,
    },
  },
};

export default nextConfig;
